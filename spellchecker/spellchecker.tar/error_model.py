import Levenshtein
import dill 
import numpy as np 
from collections import defaultdict
import json

def flatten_dictionary(dictionary):
    values = []
    for d in dictionary.values():
        for v in d.values():
            values.append(v)
    return values

class ErrorModel:

    def __init__(self):
        self.statistics = defaultdict(lambda: defaultdict(int))
    
    def update_statistics(self, given, fixed):
        operations = Levenshtein.opcodes(given, fixed)
        for op in operations:
            name, i1, i2, j1, j2 = op[0], op[1], op[2], op[3], op[4]
            if name == 'insert':
                for c in fixed[j1:j2]:
                    self.statistics[''][c] += 1
            if name == 'delete':
                for c in given[i1:i2]:
                    self.statistics[c][''] += 1
            if name == 'replace':
                for c1, c2 in zip(given[i1:i2], fixed[j1:j2]):
                    self.statistics[c1][c2] += 1
                    
    def load_json(self, json_path):
        stat = json.loads(open(json_path, "r").read())
        self.statistics =  stat
        self.calculate_weights()

    def store_json(self, json_path):
        file = open(json_path, "w")
        file.write(json.dumps((self.statistics)))
        file.close()
  
    def calculate_weights(self):
        frequencies_to_weights, default_weight = ErrorModel.prepare_weights(
            (flatten_dictionary(self.statistics)))

        self.weights = defaultdict(
            lambda: defaultdict(lambda: default_weight))
        for k1, v in self.statistics.items():
            for k2 in v.keys():
                self.weights[k1][ k2] =\
                    frequencies_to_weights[self.statistics[k1][k2]]
    @staticmethod
    def prepare_weights(values):
        list_frequencies = np.sort(np.array(values))[::-1]
        list_weights = np.log1p(list_frequencies).astype(float)[::-1]
        list_frequencies_to_weights = {}
        for i in range(len(list_frequencies)):
            list_frequencies_to_weights[list_frequencies[i]] = list_weights[i]
        default_weight = np.max(list_weights)
        return list_frequencies_to_weights, default_weight
